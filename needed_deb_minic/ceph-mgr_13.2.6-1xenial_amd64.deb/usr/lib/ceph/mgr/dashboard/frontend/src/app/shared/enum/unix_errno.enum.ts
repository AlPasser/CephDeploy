// http://www.virtsync.com/c-error-codes-include-errno
export enum UnixErrno {
  EEXIST = 17, // File exists
}
