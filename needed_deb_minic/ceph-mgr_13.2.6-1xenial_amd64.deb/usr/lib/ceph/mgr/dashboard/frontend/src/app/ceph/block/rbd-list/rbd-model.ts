export class RbdModel {
  name: string;
  pool_name: string;

  cdExecuting: string;
}
