export enum NotificationType {
  error,
  info,
  success
}
