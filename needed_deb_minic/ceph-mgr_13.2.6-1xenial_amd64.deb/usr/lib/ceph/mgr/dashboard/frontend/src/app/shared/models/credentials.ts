export class Credentials {
  username: string;
  password: string;
  stay_signed_in = false;
}
