export class Task {
  name: string;
  metadata: object;

  description: string;
}
