export class RbdParentModel {
  image_name: string;
  pool_name: string;
  snap_name: string;
}
