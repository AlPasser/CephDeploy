export class TaskException {
  status: number;
  errno: number;
  component: string;
  detail: string;
}
