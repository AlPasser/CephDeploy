import { PasswordButtonDirective } from './password-button.directive';

describe('PasswordButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordButtonDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
