export class RbdFormModel {
  name: string;
  pool_name: string;
  data_pool: string;
  size: number;
  obj_size: number;
  stripe_unit: number;
  stripe_count: number;
}
