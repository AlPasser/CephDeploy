import { Copy2ClipboardButtonDirective } from './copy2clipboard-button.directive';

describe('Copy2clipboardButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new Copy2ClipboardButtonDirective(null, null, null);
    expect(directive).toBeTruthy();
  });
});
