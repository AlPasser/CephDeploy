export enum ViewCacheStatus {
  ValueOk = 0,
  ValueStale = 1,
  ValueNone = 2,
  ValueException = 3
}
