export class RgwUserS3Key {
  user: string;
  generate_key?: boolean;
  access_key: string;
  secret_key: string;
}
