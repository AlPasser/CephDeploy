export class RbdFormEditRequestModel {
  name: string;
  size: number;
  features: Array<string> = [];
}
