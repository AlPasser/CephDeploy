/* This file is auto generated, version 201804190330 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201804190330 SMP Thu Apr 19 07:34:21 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
